function summonGolem() {
    const golems = [
        "Stone Golem has awakened!",
        "Clay Golem rises from the earth!",
        "Iron Golem stands guard!",
        "Ancient Golem emerges from ruins!"
    ];
    const random = golems[Math.floor(Math.random() * golems.length)];
    document.getElementById("golem").innerText = random;
}
